function test1_principalSkewAngle ( rootDir )
%% KC, Santosh 
% A prototype to compute derivative and variance of the signal
% Derivative helps in computing orientation value.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


close all; clc; clear all;
rootDir = '~/Documents/teaching/csc592-advComputerVision/project_code'; % inputDir.
projectName = 'derivative_orientation';
workDir = fullfile(rootDir, projectName);


cd(workDir);
inputImages = 'textureData'; imgExt = '.jpg';
imageDir = [pwd filesep inputImages];
st_imageDir = dir([imageDir filesep '*' imgExt]);
no_imageDir = numel(st_imageDir);


fid1 = fopen(fullfile(workDir, 'texturePlots', 'skewAngle.txt'), 'w');

for n = 1: no_imageDir
    [~, fileName, extName] = fileparts(st_imageDir(n).name);
    run_image = fullfile(imageDir, strcat(fileName, extName));
    run_imageRead = imread(run_image);
    
    
    %% call function to compute variance, derivate, skew angle
    p = path;
    path(p, fullfile(workDir, 'codes'));
    [ varR, dR2, skewAngle ] = principalSkewAngle( run_imageRead, workDir );
    
   
    %% call functions to plot (note that you can use just one function for two different plots)
    variancePlot(varR, 'texturePlots', fileName);
    derivative2Plot (dR2, 'texturePlots', fileName);
    
    %% save skewAngle
    fprintf(fid1, '%10s %2f\n', fileName, skewAngle);
    close all;
end

fclose(fid1);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% F1. 
function [] = variancePlot (varR, dirName, imageName)

figure('Position', [100 100 500 240]);
list = [1:180];
plot(list,varR,'-rs','LineWidth',1,...
                'MarkerEdgeColor','r',...
                'MarkerFaceColor','w',...
                'MarkerSize',2)
hold on;
axis ([0 180 -inf inf]);
grid on ;
set(gca, 'FontSize', 18);
set(gca,'XTick',[0:20:180], 'FontSize', 18);
%set(gca,'YTick',[-inf,inf], 'FontSize', 20);
set(gcf, 'PaperPositionMode', 'auto')
xlabel('\theta angle (degree)','FontSize', 20, 'fontName','times','fontweight','n');
ylabel('Variance','FontSize', 20, 'fontName','times','fontweight','n');
hold off;
print ('-dpdf', [strcat([dirName,'/'], imageName, '_varR','.pdf')]);
print ('-dpng', [strcat([dirName,'/'], imageName, '_varR','.png')]);

end

%% F2. 
function [ ] = derivative2Plot (dR2, dirName, imageName)

figure('Position', [100 100 500 240]);
list = [1:180];
plot(list,dR2,'-rs','LineWidth',1,...
                'MarkerEdgeColor','r',...
                'MarkerFaceColor','w',...
                'MarkerSize',2)
hold on;
axis ([0 180 -inf inf]);
grid on ;
set(gca, 'FontSize', 18);
set(gca,'XTick',[0:20:180], 'FontSize', 18);
%set(gca,'YTick',[-inf,inf], 'FontSize', 20);
set(gcf, 'PaperPositionMode', 'auto')
xlabel('angle (\theta in degree)','FontSize', 20, 'fontName','times','fontweight','n');
ylabel('2^{nd} derivative','FontSize', 20, 'fontName','times','fontweight','n');
hold off;
print ('-dpdf', [strcat([dirName,'/'], imageName, '_deriv2', '.pdf')]);
print ('-dpng', [strcat([dirName,'/'], imageName, '_deriv2','.png')]);
end



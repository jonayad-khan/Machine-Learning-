function [ varR, dR2, skewAngle ] = principalSkewAngle( image1, workDir )
%% K.C. Santosh July 22, 2013
% the idea is texture-based and thus no need to be precise what is in the object.
% image1 = input image
% varR = variance of the projection
% dR2 = second derivative of the variance
% skewAngle = output
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% want to test the code? uncomment the following
% close all; clc; clear all;
% rootDir = '~/Documents/MATLAB';
% projectName = 'project1';
% workDir = fullfile(rootDir, projectName);
% cd(workDir);
% image1 = imread('textureData/texture1.jpg'); 
% image1 = imread('tileshop.jpg');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% path for codes
p = path;
path(p, fullfile(workDir, 'codes'));

%%  step 1.
image1BW = im2bw(image1); % image1 given


%% step 2. edge detection, and compare the results...
% image1CropExt = edge(~image1BW,'canny');
% figure; imshow(~image1CropExt);
%%% Avoid this part for unnecessary morphological operators.


%% step 3. computing orientation angle - the most dominant one
theta = [0:179];
[ R, Xp ] = radon(~image1BW, theta);
Rsquared = R.*R;  %Rnorm = log10(Rsquared); we do not need to normalise
varR = var(Rsquared,1);
dR2 = derivative (varR,2); 
[maxV, maxI] = min(dR2);                                %% angle rotation finding

%%  return
[ maxInew] =  normalise_maxI ( maxI); % [ maxInew, varRnew, dR2new ] =  normalise_maxI ( maxI, varR, dR2 ); 
skewAngle = maxInew;
varR;
dR2;

%% NB.
% Reference vert. line i.e., 90 deg. has been changed to hor. line i.e., 0 deg.
% while we keep    varR and dR2, the same.
end


function [ maxInew] =  normalise_maxI ( maxI )
if maxI > 90;
 	maxInew = maxI-91; %         
%     varRnew  =  circshift(varR, [0,-90]);
%     dR2new  =  circshift(dR2, [0,-90]);
elseif maxI<=90
        maxInew = maxI+89; %        
%         varRnew  =  circshift(varR, [0,-(maxI-1)]);
%         dR2new  =  circshift(dR2, [0,-(maxI-1)]);
 end
 %% return
maxInew;       %1
% varRnew;        %2
% dR2new;         %3
end